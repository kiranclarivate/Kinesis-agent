/*
 * Copyright (c) 2014-2016 Amazon.com, Inc. All Rights Reserved.
 */
/**
 * Test support for the package {@code com.amazon.kinesis.streaming.agent}.
 */
package com.amazon.kinesis.streaming.agent.testing;